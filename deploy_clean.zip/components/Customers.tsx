import React, { useMemo, useState } from 'react';
import type { Trip, Customer } from '../types';
import { CustomersIcon, WhatsAppIcon } from './icons';
import { formatPhoneNumber } from '../utils';

interface CustomersProps {
  trips: Trip[];
  onCustomerClick: (customer: Customer) => void;
}

const getTripPlural = (count: number) => {
    if (count === 1) return 'توصيلة واحدة';
    if (count === 2) return 'توصيلتان';
    if (count >= 3 && count <= 10) return `${count} توصيلات`;
    return `${count} توصيلة`;
}

const Customers: React.FC<CustomersProps> = ({ trips, onCustomerClick }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredCustomers = useMemo<Customer[]>(() => {
    const customerMap = new Map<string, Customer>();

    trips.forEach(trip => {
        if (!trip.customerName) return;

        const key = `${trip.customerName}-${trip.customerPhone}`.toLowerCase();
        if (customerMap.has(key)) {
            const existingCustomer = customerMap.get(key)!;
            existingCustomer.tripCount += 1;
            existingCustomer.totalEarnings += trip.earnings;
        } else {
            customerMap.set(key, {
                name: trip.customerName,
                phone: trip.customerPhone,
                tripCount: 1,
                totalEarnings: trip.earnings,
            });
        }
    });

    const allCustomers = Array.from(customerMap.values());
    
    const filtered = searchTerm
      ? allCustomers.filter(c => c.name.toLowerCase().includes(searchTerm.toLowerCase()))
      : allCustomers;
      
    return filtered.sort((a, b) => b.totalEarnings - a.totalEarnings);
  }, [trips, searchTerm]);

  const handleWhatsAppClick = (e: React.MouseEvent, phone: string) => {
    e.stopPropagation(); // Prevent triggering the row click
    if (!phone) return;
    const number = formatPhoneNumber(phone);
    const message = encodeURIComponent(`مرحباً، معك مندوب التوصيل بخصوص طلبك.\nللتواصل: 0557667004`);
    window.open(`https://wa.me/${number}?text=${message}`, '_blank');
  };


  return (
    <div className="p-4 md:p-6">
      <header className="mb-6">
        <h1 className="text-3xl font-bold text-white">العملاء</h1>
        <p className="text-slate-400">انقر على العميل لعرض سجل توصيلاته الكامل.</p>
      </header>
      <div className="mb-4">
        <input
          type="search"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="ابحث عن عميل..."
          className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-white"
        />
      </div>

      <div className="space-y-3">
        {filteredCustomers.length > 0 ? (
          filteredCustomers.map(customer => {
            const customerKey = `${customer.name}-${customer.phone}`.toLowerCase();
            const hasPhone = customer.phone && customer.phone.trim() !== '';

            return (
              <div 
                key={customerKey} 
                onClick={() => onCustomerClick(customer)}
                className="bg-slate-800 p-4 rounded-lg flex justify-between items-center shadow-md transition-colors hover:bg-slate-700 cursor-pointer"
              >
                <div className="flex items-center gap-4 flex-grow truncate">
                    <div className="truncate">
                        <p className="font-bold text-lg text-white truncate">{customer.name}</p>
                        <p className="text-slate-400">{customer.phone || 'لا يوجد رقم هاتف'}</p>
                    </div>
                </div>

                <div className="flex items-center gap-3 sm:gap-4 flex-shrink-0">
                    <div className="text-left hidden sm:block">
                        <p className="font-semibold text-green-400">{customer.totalEarnings.toFixed(2)} ر.س</p>
                        <p className="text-sm text-slate-500">{getTripPlural(customer.tripCount)}</p>
                    </div>
                    {hasPhone && (
                        <button onClick={(e) => handleWhatsAppClick(e, customer.phone)} title="مراسلة عبر واتساب" className="text-slate-200 bg-green-500 hover:bg-green-600 rounded-full p-2 transition-colors">
                            <WhatsAppIcon className="w-6 h-6" />
                        </button>
                    )}
                </div>
            </div>
            )
          })
        ) : (
          <div className="text-center py-20 bg-slate-800 rounded-lg">
             <CustomersIcon className="w-16 h-16 mx-auto text-slate-600 mb-4" />
            <p className="text-slate-400 text-lg">{searchTerm ? 'لا يوجد عملاء مطابقون للبحث.' : 'لا يوجد عملاء بعد.'}</p>
            <p className="text-slate-500">{searchTerm ? 'جرّب البحث باسم آخر.' : 'سيظهر عملاؤك هنا بعد تسجيل التوصيلات.'}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default Customers;