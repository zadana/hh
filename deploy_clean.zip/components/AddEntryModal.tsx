import React, { useState, useEffect } from 'react';
import type { Trip, Expense } from '../types';
import { CloseIcon, MotorcycleIcon, ExpenseIcon } from './icons';

interface AddEntryModalProps {
  isOpen: boolean;
  onClose: () => void;
  addTrip: (trip: Omit<Trip, 'id' | 'date'>) => void;
  addExpense: (expense: Omit<Expense, 'id' | 'date'>) => void;
  updateTrip: (trip: Trip) => void;
  updateExpense: (expense: Expense) => void;
  entryToEdit: Trip | Expense | null;
  initialFormType: 'trip' | 'expense';
}

const AddEntryModal: React.FC<AddEntryModalProps> = ({ 
    isOpen, 
    onClose, 
    addTrip, 
    addExpense,
    updateTrip,
    updateExpense,
    entryToEdit,
    initialFormType
}) => {
  const [formType, setFormType] = useState(initialFormType);
  const isEditMode = entryToEdit !== null;

  // Trip state
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [earnings, setEarnings] = useState('');

  // Expense state
  const [description, setDescription] = useState('');
  const [amount, setAmount] = useState('');
  
  useEffect(() => {
    if (isOpen) {
        setFormType(initialFormType);
        if (entryToEdit) {
            if ('earnings' in entryToEdit) { // Trip
                setCustomerName(entryToEdit.customerName);
                setCustomerPhone(entryToEdit.customerPhone);
                setEarnings(entryToEdit.earnings.toString());
            } else { // Expense
                setDescription(entryToEdit.description);
                setAmount(entryToEdit.amount.toString());
            }
        } else {
            resetForms();
        }
    }
  }, [isOpen, entryToEdit, initialFormType]);

  const handleTripSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (customerName && earnings) {
      const tripData = { customerName, customerPhone, earnings: parseFloat(earnings) };
      if(isEditMode && entryToEdit && 'earnings' in entryToEdit) {
        updateTrip({ ...entryToEdit, ...tripData });
      } else {
        addTrip(tripData);
      }
      onClose();
    }
  };

  const handleExpenseSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (description && amount) {
        const expenseData = { description, amount: parseFloat(amount) };
        if(isEditMode && entryToEdit && 'amount' in entryToEdit) {
            updateExpense({ ...entryToEdit, ...expenseData });
        } else {
            addExpense(expenseData);
        }
        onClose();
    }
  };

  const resetForms = () => {
    setCustomerName('');
    setCustomerPhone('');
    setEarnings('');
    setDescription('');
    setAmount('');
  };
  
  if (!isOpen) return null;

  const activeTabClass = "bg-slate-700 text-white";
  const inactiveTabClass = "bg-slate-800 text-slate-400 hover:bg-slate-700";

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl shadow-2xl w-full max-w-md mx-auto text-white transform transition-all scale-100 opacity-100" onClick={e => e.stopPropagation()}>
        <div className="p-6 relative">
          <button onClick={onClose} className="absolute top-4 left-4 right-auto text-slate-500 hover:text-white transition-colors">
            <CloseIcon className="w-6 h-6" />
          </button>
          
          <div className="flex border-b border-slate-700 mb-6">
            <button onClick={() => setFormType('trip')} className={`flex-1 p-4 rounded-tr-lg text-lg font-bold flex items-center justify-center gap-2 transition-colors ${formType === 'trip' ? activeTabClass : inactiveTabClass}`} disabled={isEditMode}>
                <MotorcycleIcon className="w-6 h-6" /> توصيلة
            </button>
            <button onClick={() => setFormType('expense')} className={`flex-1 p-4 rounded-tl-lg text-lg font-bold flex items-center justify-center gap-2 transition-colors ${formType === 'expense' ? activeTabClass : inactiveTabClass}`} disabled={isEditMode}>
                <ExpenseIcon className="w-6 h-6" /> مصروف
            </button>
          </div>

          {formType === 'trip' ? (
            <form onSubmit={handleTripSubmit} className="space-y-4">
              <h2 className="text-2xl font-bold text-center text-blue-400 mb-2">{isEditMode ? 'تعديل التوصيلة' : 'تسجيل توصيلة جديدة'}</h2>
              <div>
                <label className="text-sm font-medium text-slate-400">اسم العميل</label>
                <input type="text" value={customerName} onChange={e => setCustomerName(e.target.value)} className="w-full mt-1 p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="مثال: أحمد محمد" required />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-400">هاتف العميل</label>
                <input type="tel" value={customerPhone} onChange={e => setCustomerPhone(e.target.value)} className="w-full mt-1 p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="(اختياري)" />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-400">الأرباح</label>
                <input type="number" value={earnings} onChange={e => setEarnings(e.target.value)} className="w-full mt-1 p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none" placeholder="٠.٠٠" step="0.01" required />
              </div>
              <button type="submit" className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-4 rounded-lg transition-colors text-lg">{isEditMode ? 'تحديث التوصيلة' : 'إضافة توصيلة'}</button>
            </form>
          ) : (
            <form onSubmit={handleExpenseSubmit} className="space-y-4">
              <h2 className="text-2xl font-bold text-center text-red-400 mb-2">{isEditMode ? 'تعديل المصروف' : 'تسجيل مصروف جديد'}</h2>
              <div>
                <label className="text-sm font-medium text-slate-400">الوصف</label>
                <input type="text" value={description} onChange={e => setDescription(e.target.value)} className="w-full mt-1 p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none" placeholder="مثال: وقود" required />
              </div>
              <div>
                <label className="text-sm font-medium text-slate-400">المبلغ</label>
                <input type="number" value={amount} onChange={e => setAmount(e.target.value)} className="w-full mt-1 p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-red-500 focus:border-red-500 outline-none" placeholder="٠.٠٠" step="0.01" required />
              </div>
              <button type="submit" className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-4 rounded-lg transition-colors text-lg">{isEditMode ? 'تحديث المصروف' : 'إضافة مصروف'}</button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export default AddEntryModal;