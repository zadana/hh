import React, { useMemo } from 'react';
import type { Trip, Expense } from '../types';
import { MotorcycleIcon, ExpenseIcon } from './icons';

interface DashboardProps {
  trips: Trip[];
  expenses: Expense[];
}

const isToday = (someDate: Date) => {
    const today = new Date();
    return someDate.getDate() === today.getDate() &&
        someDate.getMonth() === today.getMonth() &&
        someDate.getFullYear() === today.getFullYear();
};

const isThisMonth = (someDate: Date) => {
    const today = new Date();
    return someDate.getMonth() === today.getMonth() &&
        someDate.getFullYear() === today.getFullYear();
};

const StatCard: React.FC<{ title: string, value: string, colorClass: string }> = ({ title, value, colorClass }) => (
    <div className={`bg-slate-800 p-6 rounded-2xl shadow-lg flex flex-col justify-between border-r-4 border-l-0 ${colorClass}`}>
        <p className="text-slate-400 text-md font-medium">{title}</p>
        <p className="text-3xl font-bold text-white mt-2">{value}</p>
    </div>
);

const ActivityItem: React.FC<{ item: Trip | Expense }> = ({ item }) => {
    const isTrip = 'earnings' in item;
    return (
        <div className="flex items-center justify-between p-4 bg-slate-800 rounded-lg">
            <div className="flex items-center gap-4">
                <div className={`p-2 rounded-full ${isTrip ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                    {isTrip ? <MotorcycleIcon className="w-6 h-6 text-green-400" /> : <ExpenseIcon className="w-6 h-6 text-red-400" />}
                </div>
                <div>
                    <p className="font-semibold text-white">{isTrip ? item.customerName : item.description}</p>
                    <p className="text-sm text-slate-400">{item.date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
            </div>
            <p className={`font-bold text-lg ${isTrip ? 'text-green-400' : 'text-red-400'}`}>
                {isTrip ? `+` : `-`}{item[isTrip ? 'earnings' : 'amount'].toFixed(2)}
            </p>
        </div>
    );
};

const Dashboard: React.FC<DashboardProps> = ({ trips, expenses }) => {

    const { todayIncome, todayTrips, monthIncome, monthExpenses } = useMemo(() => {
        let todayIncome = 0;
        let todayTrips = 0;
        let monthIncome = 0;
        let monthExpenses = 0;
        
        trips.forEach(trip => {
            if (isToday(trip.date)) {
                todayIncome += trip.earnings;
                todayTrips++;
            }
            if(isThisMonth(trip.date)) {
                monthIncome += trip.earnings;
            }
        });
        
        expenses.forEach(expense => {
            if (isThisMonth(expense.date)) {
                monthExpenses += expense.amount;
            }
        });

        return { todayIncome, todayTrips, monthIncome, monthExpenses };
    }, [trips, expenses]);

    const recentActivity = useMemo(() => {
        return [...trips, ...expenses]
            .sort((a, b) => b.date.getTime() - a.date.getTime())
            .slice(0, 5);
    }, [trips, expenses]);

    return (
        <div className="p-4 md:p-6 space-y-6">
            <header>
                <h1 className="text-3xl font-bold text-white">الرئيسية</h1>
                <p className="text-slate-400">إليك ملخصك المالي لهذا اليوم.</p>
            </header>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <StatCard title="دخل اليوم" value={`${todayIncome.toFixed(2)} ر.س`} colorClass="border-green-500" />
                <StatCard title="توصيلات اليوم" value={todayTrips.toString()} colorClass="border-blue-500" />
                <StatCard title="صافي ربح الشهر" value={`${(monthIncome - monthExpenses).toFixed(2)} ر.س`} colorClass="border-purple-500" />
            </div>

            <div>
                <h2 className="text-xl font-bold text-white mb-4">النشاط الأخير</h2>
                <div className="space-y-3">
                    {recentActivity.length > 0 ? (
                        recentActivity.map(item => <ActivityItem key={item.id} item={item} />)
                    ) : (
                        <div className="text-center py-10 bg-slate-800 rounded-lg">
                            <p className="text-slate-400">لا يوجد نشاط حديث لعرضه.</p>
                            <p className="text-slate-500 text-sm">أضف توصيلة أو مصروفاً للبدء!</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Dashboard;