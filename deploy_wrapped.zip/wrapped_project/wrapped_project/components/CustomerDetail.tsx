import React from 'react';
import type { Customer, Trip } from '../types';
import { MotorcycleIcon } from './icons';

interface CustomerDetailProps {
  customer: Customer;
  allTrips: Trip[];
  onBack: () => void;
}

const TripHistoryItem: React.FC<{ trip: Trip }> = ({ trip }) => {
    return (
        <div className="flex items-center justify-between p-4 bg-slate-800 rounded-lg">
            <div className="flex items-center gap-4">
                <div className={`p-2 rounded-full bg-green-500/20`}>
                    <MotorcycleIcon className="w-6 h-6 text-green-400" />
                </div>
                <div>
                    <p className="font-semibold text-white">توصيلة</p>
                    <p className="text-sm text-slate-400">{trip.date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
            </div>
            <p className="font-bold text-lg text-green-400">
                +{trip.earnings.toFixed(2)} ر.س
            </p>
        </div>
    );
};

const DateHeader: React.FC<{ date: Date }> = ({ date }) => (
    <h3 className="text-slate-400 font-semibold mt-6 mb-2 mr-2">
        {date.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
    </h3>
);


const CustomerDetail: React.FC<CustomerDetailProps> = ({ customer, allTrips, onBack }) => {
    
    const customerTrips = React.useMemo(() => {
        return allTrips
            .filter(trip => trip.customerName === customer.name && trip.customerPhone === customer.phone)
            .sort((a, b) => b.date.getTime() - a.date.getTime());
    }, [allTrips, customer]);
    
    let lastDate: string | null = null;
    
    const getTripPlural = (count: number) => {
        if (count === 1) return 'توصيلة واحدة';
        if (count === 2) return 'توصيلتان';
        if (count >= 3 && count <= 10) return `${count} توصيلات`;
        return `${count} توصيلة`;
    }

    return (
        <div className="p-4 md:p-6">
            <header className="mb-6 flex items-center gap-4">
                <button onClick={onBack} className="p-2 bg-slate-800 rounded-full hover:bg-slate-700 transition-colors">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 8l4 4m0 0l-4 4m4-4H3" />
                    </svg>
                </button>
                <div>
                    <h1 className="text-3xl font-bold text-white">{customer.name}</h1>
                    <p className="text-slate-400">{customer.phone || 'لا يوجد رقم هاتف'}</p>
                </div>
            </header>
            
            <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-slate-800 p-4 rounded-lg text-center">
                    <p className="text-slate-400">إجمالي التوصيلات</p>
                    <p className="text-2xl font-bold text-blue-400">{getTripPlural(customer.tripCount)}</p>
                </div>
                 <div className="bg-slate-800 p-4 rounded-lg text-center">
                    <p className="text-slate-400">إجمالي الأرباح</p>
                    <p className="text-2xl font-bold text-green-400">{customer.totalEarnings.toFixed(2)} ر.س</p>
                </div>
            </div>
            
            <h2 className="text-2xl font-bold text-white mb-4">سجل التوصيلات</h2>
            
            <div className="space-y-2">
                {customerTrips.length > 0 ? (
                    customerTrips.map(trip => {
                        const currentDate = trip.date.toDateString();
                        const showHeader = currentDate !== lastDate;
                        lastDate = currentDate;
                        return (
                            <React.Fragment key={trip.id}>
                                {showHeader && <DateHeader date={trip.date} />}
                                <TripHistoryItem trip={trip} />
                            </React.Fragment>
                        );
                    })
                ) : (
                    <div className="text-center py-20 bg-slate-800 rounded-lg">
                        <p className="text-slate-400 text-lg">لا يوجد سجل توصيلات لهذا العميل.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default CustomerDetail;
