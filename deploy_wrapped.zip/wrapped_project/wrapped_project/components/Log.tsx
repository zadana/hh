import React, { useMemo, useState } from 'react';
import type { Trip, Expense } from '../types';
import { MotorcycleIcon, ExpenseIcon, EditIcon, TrashIcon, WhatsAppIcon } from './icons';
import { formatPhoneNumber } from '../utils';

interface LogProps {
  trips: Trip[];
  expenses: Expense[];
  onEdit: (entry: Trip | Expense) => void;
  onDelete: (id: string) => void;
}

const LogItem: React.FC<{ item: Trip | Expense; onEdit: () => void; onDelete: () => void }> = ({ item, onEdit, onDelete }) => {
    const isTrip = 'earnings' in item;
    const hasPhone = isTrip && item.customerPhone && item.customerPhone.trim() !== '';

    const handleWhatsAppClick = () => {
        if (!hasPhone) return;
        const number = formatPhoneNumber(item.customerPhone);
        const message = encodeURIComponent(`مرحباً، معك مندوب التوصيل بخصوص طلبك.\nللتواصل: 0557667004`);
        window.open(`https://wa.me/${number}?text=${message}`, '_blank');
    };
    
    return (
        <div className="flex items-center justify-between p-4 bg-slate-800 rounded-lg shadow-md gap-2">
            <div className="flex items-center gap-4 overflow-hidden">
                <div className={`p-2 rounded-full flex-shrink-0 ${isTrip ? 'bg-green-500/20' : 'bg-red-500/20'}`}>
                    {isTrip ? <MotorcycleIcon className="w-6 h-6 text-green-400" /> : <ExpenseIcon className="w-6 h-6 text-red-400" />}
                </div>
                <div className="truncate">
                    <p className="font-semibold text-white truncate">{isTrip ? item.customerName : item.description}</p>
                    <p className="text-sm text-slate-400">{item.date.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}</p>
                </div>
            </div>
            <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
                 <p className={`font-bold text-lg ${isTrip ? 'text-green-400' : 'text-red-400'}`}>
                    {isTrip ? `+` : `-`}{item[isTrip ? 'earnings' : 'amount'].toFixed(2)}
                </p>
                {hasPhone && (
                    <button onClick={handleWhatsAppClick} title="مراسلة عبر واتساب" className="text-green-400 hover:text-green-300 transition-colors">
                        <WhatsAppIcon className="w-5 h-5" />
                    </button>
                )}
                <button onClick={onEdit} className="text-slate-400 hover:text-blue-400 transition-colors"><EditIcon className="w-5 h-5" /></button>
                <button onClick={onDelete} className="text-slate-400 hover:text-red-400 transition-colors"><TrashIcon className="w-5 h-5" /></button>
            </div>
        </div>
    );
};

const DateHeader: React.FC<{ date: Date }> = ({ date }) => (
    <h3 className="text-slate-400 font-semibold mt-6 mb-2 mr-2">
        {date.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
    </h3>
);

const Log: React.FC<LogProps> = ({ trips, expenses, onEdit, onDelete }) => {
  const [searchTerm, setSearchTerm] = useState('');

  const filteredLog = useMemo(() => {
    const combined = [...trips, ...expenses].sort((a, b) => b.date.getTime() - a.date.getTime());
    if (!searchTerm) {
        return combined;
    }
    return combined.filter(item => {
        const term = searchTerm.toLowerCase();
        if ('earnings' in item) { // Trip
            return item.customerName.toLowerCase().includes(term) || item.earnings.toString().includes(term);
        } else { // Expense
            return item.description.toLowerCase().includes(term) || item.amount.toString().includes(term);
        }
    });
  }, [trips, expenses, searchTerm]);

  let lastDate: string | null = null;

  return (
    <div className="p-4 md:p-6">
        <header className="mb-6">
            <h1 className="text-3xl font-bold text-white">سجل النشاط</h1>
            <p className="text-slate-400">سجل كامل لجميع توصيلاتك ومصروفاتك.</p>
        </header>
        <div className="mb-4">
             <input
                type="search"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="ابحث عن توصيلة أو مصروف..."
                className="w-full p-3 bg-slate-700 border border-slate-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none text-white"
            />
        </div>
        <div className="space-y-2">
            {filteredLog.length > 0 ? (
                filteredLog.map(item => {
                    const currentDate = item.date.toDateString();
                    const showHeader = currentDate !== lastDate;
                    lastDate = currentDate;
                    return (
                        <React.Fragment key={item.id}>
                            {showHeader && <DateHeader date={item.date} />}
                            <LogItem item={item} onEdit={() => onEdit(item)} onDelete={() => onDelete(item.id)} />
                        </React.Fragment>
                    );
                })
            ) : (
                <div className="text-center py-20 bg-slate-800 rounded-lg">
                    <p className="text-slate-400 text-lg">{searchTerm ? 'لا توجد نتائج مطابقة.' : 'سجلك فارغ.'}</p>
                    <p className="text-slate-500">{searchTerm ? 'جرّب كلمة بحث مختلفة.' : 'ستظهر جميع توصيلاتك ومصروفاتك المسجلة هنا.'}</p>
                </div>
            )}
        </div>
    </div>
  );
};

export default Log;