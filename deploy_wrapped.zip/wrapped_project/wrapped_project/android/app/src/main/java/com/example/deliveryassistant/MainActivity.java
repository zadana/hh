package com.example.deliveryassistant;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
