### بناء وتثبيت تطبيق Android (Capacitor)

هذا الملف يشرح كيفية بناء التطبيق محليًا والحصول على ملف `app-debug.apk` جاهز للتثبيت على جهاز Android.

متطلبات سابقة (على جهازك):
- Android Studio (توفر SDK وGradle وJDK) أو حد أدنى: OpenJDK 11/17 + Android SDK command-line tools + platform-tools
- Node.js و npm

خيارات البناء
1) Android Studio (موصى به)
   - فكّ `android.zip` أو افتح مجلد `android/` في Android Studio: File → Open → اختر المجلد `android`.
   - انتظر مزامنة Gradle.
   - من القائمة: Build → Build Bundle(s) / APK(s) → Build APK(s).
   - الناتج: `android/app/build/outputs/apk/debug/app-debug.apk`.

2) سطر أوامر (CLI)
   - تأكد من ضبط متغيرات البيئة لـ ANDROID_SDK_ROOT ووجود `sdkmanager`, `adb` في PATH.
   - من جذر المشروع شغّل الأوامر التالية:
     ```bash
     # تثبيت تبعيات node
     npm ci

     # بناء ملفات الويب (Vite)
     npm run build

     # نسخ أصول الويب إلى المشروع Android
     npx cap copy android

     # ادخل مجلد android وابنِ APK
     cd android
     ./gradlew assembleDebug --no-daemon
     # الناتج في: app/build/outputs/apk/debug/app-debug.apk
     ```

تثبيت الـAPK على الهاتف
- عبر USB وADB:
  ```bash
  adb devices
  adb install -r android/app/build/outputs/apk/debug/app-debug.apk
  ```
- أو انقل الملف إلى الهاتف وافتحه وثبت (تأكد من السماح بتثبيت من مصادر غير معروفة).

ملاحظات عملية
- ملف `android_fixed.zip` موجود في جذر المشروع إذا أردت نقله مباشرة إلى جهاز لديك أو إلى شخص آخر.
- إذا أردت نسخة موقّعة (release) للنشر على Play Store أحتاج لإنشاء keystore وتكوين signingConfig. أستطيع مساعدتك بإعداد workflow مخصص لذلك.

إذا واجهت أخطاء أثناء `./gradlew assembleDebug` أرسل لي كامل مخرجات الخطأ (خصوصًا آخر 200 سطر) وسأحلّلها وأعدّل الملفات اللازمة.
