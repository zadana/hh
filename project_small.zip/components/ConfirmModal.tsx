import React from 'react';
import { TrashIcon } from './icons';

interface ConfirmModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: string;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({ isOpen, onClose, onConfirm, title, message }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center p-4 z-50" onClick={onClose}>
      <div className="bg-slate-800 rounded-2xl shadow-2xl w-full max-w-sm mx-auto text-white transform transition-all scale-100 opacity-100" onClick={e => e.stopPropagation()}>
        <div className="p-8 text-center">
          <div className="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-red-900/50 mb-4 border-2 border-red-500/30">
            <TrashIcon className="h-8 w-8 text-red-400" />
          </div>
          <h3 className="text-xl font-bold text-white">{title}</h3>
          <p className="text-sm text-slate-400 mt-2 leading-relaxed">{message}</p>
          <div className="mt-8 flex justify-center gap-4">
            <button
              onClick={onConfirm}
              className="w-full px-6 py-3 rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold transition-colors"
            >
              نعم، قم بالحذف
            </button>
            <button
              onClick={onClose}
              className="w-full px-6 py-3 rounded-lg bg-slate-700 hover:bg-slate-600 text-white font-medium transition-colors"
            >
              إلغاء
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ConfirmModal;
