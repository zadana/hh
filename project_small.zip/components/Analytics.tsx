import React, { useMemo } from 'react';
import type { Trip, Expense } from '../types';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Legend, CartesianGrid } from 'recharts';

interface AnalyticsProps {
  trips: Trip[];
  expenses: Expense[];
}

const isThisMonth = (someDate: Date) => {
    const today = new Date();
    return someDate.getMonth() === today.getMonth() &&
        someDate.getFullYear() === today.getFullYear();
};

const Analytics: React.FC<AnalyticsProps> = ({ trips, expenses }) => {
  const { monthlyData, totalIncome, totalExpenses, netProfit } = useMemo(() => {
    const data: { [key: string]: { name: string, income: number, expenses: number } } = {};
    const today = new Date();
    const firstDayOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
    const lastDayOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);

    for (let d = firstDayOfMonth; d <= lastDayOfMonth; d.setDate(d.getDate() + 1)) {
        const day = d.getDate().toString();
        data[day] = { name: day, income: 0, expenses: 0 };
    }
    
    let totalIncome = 0;
    let totalExpenses = 0;

    trips.forEach(trip => {
      if (isThisMonth(trip.date)) {
        const day = trip.date.getDate().toString();
        data[day].income += trip.earnings;
        totalIncome += trip.earnings;
      }
    });

    expenses.forEach(expense => {
      if (isThisMonth(expense.date)) {
        const day = expense.date.getDate().toString();
        data[day].expenses += expense.amount;
        totalExpenses += expense.amount;
      }
    });

    return { monthlyData: Object.values(data), totalIncome, totalExpenses, netProfit: totalIncome - totalExpenses };
  }, [trips, expenses]);

  return (
    <div className="p-4 md:p-6 space-y-8">
      <header>
        <h1 className="text-3xl font-bold text-white">التحليلات</h1>
        <p className="text-slate-400">أداؤك المالي للشهر الحالي.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
        <div className="bg-slate-800 p-4 rounded-lg">
            <p className="text-slate-400">إجمالي الدخل</p>
            <p className="text-2xl font-bold text-green-400">{totalIncome.toFixed(2)} ر.س</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg">
            <p className="text-slate-400">إجمالي المصروفات</p>
            <p className="text-2xl font-bold text-red-400">{totalExpenses.toFixed(2)} ر.س</p>
        </div>
        <div className="bg-slate-800 p-4 rounded-lg">
            <p className="text-slate-400">صافي الربح</p>
            <p className="text-2xl font-bold text-blue-400">{netProfit.toFixed(2)} ر.س</p>
        </div>
      </div>

      <div className="bg-slate-800 p-4 rounded-2xl shadow-lg h-80">
        <h2 className="text-xl font-bold text-white mb-4">نظرة عامة شهرية</h2>
        {monthlyData.some(d => d.income > 0 || d.expenses > 0) ? (
            <ResponsiveContainer width="100%" height="100%">
                <BarChart data={monthlyData} margin={{ top: 5, right: 20, left: -20, bottom: 5 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
                    <XAxis dataKey="name" stroke="#94a3b8" />
                    <YAxis stroke="#94a3b8" yAxisId="left" orientation="left" />
                    <YAxis stroke="#94a3b8" yAxisId="right" orientation="right" />
                    <Tooltip
                        contentStyle={{ backgroundColor: '#1e293b', border: '1px solid #334155', color: '#f1f5f9' }}
                        labelStyle={{ color: '#94a3b8' }}
                        cursor={{ fill: 'rgba(148, 163, 184, 0.1)' }}
                        formatter={(value: number) => `${value.toFixed(2)} ر.س`}
                    />
                    <Legend wrapperStyle={{color: "#f1f5f9"}}/>
                    <Bar yAxisId="right" dataKey="income" fill="#4ade80" name="الدخل" />
                    <Bar yAxisId="right" dataKey="expenses" fill="#f87171" name="المصروفات" />
                </BarChart>
            </ResponsiveContainer>
        ) : (
            <div className="flex items-center justify-center h-full">
                <p className="text-slate-500">لا توجد بيانات كافية لمخطط هذا الشهر.</p>
            </div>
        )}
      </div>
    </div>
  );
};

export default Analytics;